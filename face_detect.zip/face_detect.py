# SWAMI KARUPPASWAMI THUNNAI

import base64
import requests
from flask import Flask, render_template
from flask import request
from security.security import sbp


def is_face_matched():
    with open("main.jpg", "rb") as file:
        main_image = base64.b64encode(file.read())
    with open("photo.jpg", "rb") as file:
        photo_image = base64.b64encode(file.read())
    headers = {
        "user_id": "a0d9685d1ac3b2572e09",
        "user_key": "a2c01b51344aea58e8f0"
    }

    body = {
        "img_1": main_image,
        "img_2": photo_image
    }
    r = requests.post("http://www.facexapi.com/compare_faces?face_det=1", headers=headers, data=body)
    confidence = r.json()["confidence"]
    confidence = float(confidence)
    if confidence > 0.5:
        return True
    else:
        return False


app = Flask(__name__)


@app.route("/")
def main_func():
    return render_template("main.html")


@app.route("/login", methods=["POST"])
def login():
    file = request.files["photo"]
    file.save("photo.jpg")
    if is_face_matched():
        return render_template("success.html")
    return render_template("failure.html")


@app.route("/add")
def add():
    return render_template("add.html")


@app.route("/image_add", methods=["POST"])
def image_add():
    photo = request.files["photo"]
    photo.save("main.jpg")
    return "<h1>Photo Added</h1>"

app.register_blueprint(sbp)


if __name__ == "__main__":
    app.run(debug=True, host="192.168.8.100")