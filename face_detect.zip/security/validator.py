# SWAMI KARUPPASWAMI THUNNAI

import time
import jwt
from functools import wraps
from flask import redirect, url_for
from flask import session
from database.get_connection import get_connection


def create_token(account_id, password):
    payload = {
        "id": account_id,
        "expiry": time.time() + 259200
    }
    encoded_payload = jwt.encode(payload, key=password+"nectar's_elixir{*}")
    return encoded_payload.decode("utf-8")


def token_validator(_function):
    @wraps(_function)
    def wrapper_function(*args, **kwargs):
        if "sec_token" not in session:
            return redirect("/security_login")
        token = session["sec_token"]
        try:
            decoded_token = jwt.decode(token, verify=False)
        except jwt.DecodeError:
            return redirect("/security_login")
        try:
            account_id = decoded_token["id"]
            expiry = decoded_token["expiry"]
            if time.time() > expiry:
                return redirect("/security_login")
        except jwt.DecodeError:
            return redirect("/security_login")
        except KeyError:
            return redirect("/security_login")
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("select password from security where id=%s", (account_id, ))
            result = cursor.fetchone()
            if result is None:
                return redirect("/security_login")
            password = result["password"]
            secret = password + "nectar's_elixir{*}"
        finally:
            cursor.close()
            connection.close()
        try:
            jwt.decode(token, key=secret)
        except jwt.DecodeError:
            return redirect("/security_login")
        return _function(*args, **kwargs)
    return wrapper_function
