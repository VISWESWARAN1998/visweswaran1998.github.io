# SWAMI KARUPPASWAMI THUNNAI

from flask import Blueprint
from flask import render_template
from flask import request, redirect, session
from database.get_connection import get_connection


sbp = Blueprint('sbp', __name__)


@sbp.route("/security_dashboard")
def dashboard():
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("select id, flat_no, name from visitor where left_timestamp is null")
        result = cursor.fetchall()
        active_visitors = []
        for index, i in enumerate(result):
            active_visitors.append([index+1, i["id"], i["flat_no"], i["name"]])
    finally:
        cursor.close()
        connection.close()
    return render_template("security_dashboard.html", active_visitors=active_visitors)


@sbp.route("/security_visitor_left", methods=["POST"])
def mark_visitor_as_left():
    visitor_id = request.form["id"]
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("update visitor set left_timestamp=current_timestamp() where id=%s", (visitor_id, ))
        connection.commit()
        return redirect("/security_dashboard")
    finally:
        cursor.close()
        connection.close()


@sbp.route("/add_visitor", methods=["POST"])
def add_visitor():
    name = request.form["name"]
    purpose = request.form["purpose"]
    flat_no = request.form["flat_no"]
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("insert into visitor value(null, %s, %s, %s, null, current_timestamp())", (name, purpose, flat_no))
        connection.commit()
        return render_template("security_entry_added.html")
    finally:
        cursor.close()
        connection.close()


@sbp.route("/vehicle_entry")
def vehicle_entry():
    return render_template("vehicle_entry.html")


@sbp.route("/assign_vehicle")
def assign_vehicle():
    return render_template("assign_vehicle.html")


@sbp.route("/add_vehicle", methods=["POST"])
def add_vehicle():
    flat_no = request.form["flat_no"]
    _license = request.form["license"]
    vehicle_type = request.form["vehicle_type"]
    if vehicle_type == "Two Wheeler":
        vehicle_type = 0
    else:
        vehicle_type = 1
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("insert into vehicle value(null, %s, %s, %s)", (flat_no, _license, vehicle_type))
        connection.commit()
        return render_template("security_entry_added.html")
    finally:
        cursor.close()


@sbp.route("/vehicles_in")
def vehilce_list():
    flat_no = request.args.get("flat_no")
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("select id, license, vehicle_type from vehicle where flat_no=%s", (flat_no))
        result = cursor.fetchall()
        vehicles = []
        for index, i in enumerate(result):
            vehicles.append([index+1, i["id"], i["vehicle_type"], i["license"]])
        return render_template("vehicles.html", vehicles=vehicles)
    finally:
        cursor.close()
        connection.close()


@sbp.route("/security_add_attendance", methods=["POST"])
def add_attendance():
    vehicle_id = request.form["id"]
    _date = request.form["date"]
    _time = request.form["time"]
    status = request.form["status"]
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("insert into vehicle_attendance value(null, %s, %s, %s, %s)", (vehicle_id, _date, _time, status))
        connection.commit()
        return redirect("/vehicle_entry")
    finally:
        cursor.close()
        connection.close()

